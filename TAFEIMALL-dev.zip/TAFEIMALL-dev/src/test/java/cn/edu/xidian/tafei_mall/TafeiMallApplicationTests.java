package cn.edu.xidian.tafei_mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TafeiMallApplicationTests {

    @Test
    void contextLoads() {
    }

}
