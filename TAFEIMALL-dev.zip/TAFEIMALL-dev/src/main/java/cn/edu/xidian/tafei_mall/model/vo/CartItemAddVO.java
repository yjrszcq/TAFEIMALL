package cn.edu.xidian.tafei_mall.model.vo;


import lombok.Data;

@Data
public class CartItemAddVO {
    private String productId;
    private int quantity;

    // Getters and Setters
}