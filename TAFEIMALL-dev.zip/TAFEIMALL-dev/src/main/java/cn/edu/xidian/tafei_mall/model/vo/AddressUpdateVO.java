package cn.edu.xidian.tafei_mall.model.vo;


import lombok.Data;

@Data
public class AddressUpdateVO {
    private String address;
    private String city;
    private String postalCode;

    // Getters and Setters
}